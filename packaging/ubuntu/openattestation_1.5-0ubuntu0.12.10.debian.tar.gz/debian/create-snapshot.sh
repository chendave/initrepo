#!/bin/sh -e

if [ -d OpenAttestation-Snapshot ]; then
    rm -Rf OpenAttestation-Snapshot
fi
git clone https://github.com/OpenAttestation/OpenAttestation.git OpenAttestation-Snapshot
commit=`cd OpenAttestation-Snapshot && git log -n1 --format=oneline --abbrev-commit | awk '{ print $1 }'`
timestamp=`date +%Y%m%d`
(
    cd OpenAttestation-Snapshot
    git archive --format=tar --prefix=openattestation-1.5~${timestamp}.${commit}/ \
            --output ../openattestation_1.5~${timestamp}.${commit}.orig.tar HEAD
)
if [ -f openattestation_1.5~${timestamp}.${commit}.orig.tar.bz2 ]; then
    rm -f openattestation_1.5~${timestamp}.${commit}.orig.tar.bz2
fi
bzip2 -9 openattestation_1.5~${timestamp}.${commit}.orig.tar

(
    cd OpenAttestation-Snapshot/Installer
    ./download_jar_packages.sh
    cd ../JAR_SOURCE
    tar -cjf ../../openattestation_1.5~${timestamp}.${commit}.orig-deps.tar.bz2 *
)

rm -Rf OpenAttestation-Snapshot
